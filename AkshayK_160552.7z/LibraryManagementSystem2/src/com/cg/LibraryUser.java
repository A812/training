package com.cg;

public interface LibraryUser {

	public void registerAccount(int age);
	public void requestBook(String bookType);
	
	
}
